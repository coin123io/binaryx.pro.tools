//
//  DCMouseTap.h
//  DCTest
//
//  Created by Nicholas Moore on 03/03/2010.
//  Copyright 2010 Nicholas Moore. All rights reserved.
//

#import <Foundation/Foundation.h>

#define INITIAL_EVENT_NUMBER (SHRT_MAX)
#define NUM_MOUSE_BUTTONS 32

#define MOVE_MASK (\
CGEventMaskBit(kCGEventMouseMoved)\
)

#define DRAG_MASK (\
CGEventMaskBit(kCGEventLeftMouseDragged)|\
CGEventMaskBit(kCGEventRightMouseDragged)|\
CGEventMaskBit(kCGEventOtherMouseDragged)\
)

#define DOWN_MASK (\
CGEventMaskBit(kCGEventLeftMouseDown)|\
CGEventMaskBit(kCGEventRightMouseDown)|\
CGEventMaskBit(kCGEventOtherMouseDown)\
)

#define UP_MASK (\
CGEventMaskBit(kCGEventLeftMouseUp)|\
CGEventMaskBit(kCGEventRightMouseUp)|\
CGEventMaskBit(kCGEventOtherMouseUp)\
)

@class FCMouseTap;

@interface FCMouseTapData : NSObject {
@public
	FCMouseTap *tap;
    BOOL buttonDown;
	short eventNumber;
	short eventNumberForButton[NUM_MOUSE_BUTTONS+1];
}
@end

@interface FCMouseTap : NSObject {
	CFMachPortRef port;
	CFRunLoopSourceRef source;
	FCMouseTapData *tapData;
}
@property (assign, getter=isActive) BOOL active;
@property (readonly, getter=isButtonDown) BOOL buttonDown;
- (void)start;
- (void)stop;
- (void)enableTap:(BOOL)state;
@end

#import <Foundation/Foundation.h>
@class NMPoint;
